// Copyright Epic Games, Inc. All Rights Reserved.

#include "GAM312.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GAM312, "GAM312" );
 